part of '../exception_utilities.dart';

///Class To handle When  NO Exception Arrive
class StaticException implements Exception {
  ///Constructor To handle When  NO Exception Arrive
  StaticException();
}
